console.log('epiTerra.js loaded, hello world at '+Date())

